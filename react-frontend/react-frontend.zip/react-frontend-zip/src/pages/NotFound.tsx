export default function NotFound(){
    return <h2>This this NotFound component</h2>
}