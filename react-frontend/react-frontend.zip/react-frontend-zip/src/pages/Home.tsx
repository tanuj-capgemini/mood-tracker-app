export default function Home(){
    return <h2>This this home component</h2>
}