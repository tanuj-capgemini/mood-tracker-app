import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import MoodForm from './components/MoodForm';
import Dashboard from './components/Dashboard';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


const App: React.FC = () => {
  return (
    <>
    <Router>
      <Routes>
        <Route path="/" element={<MoodForm />} />
        <Route path="/dashboard" element={<Dashboard />} />
      </Routes>
    </Router>
    <ToastContainer position="top-right" autoClose={2000} />
    </>
  );
};

export default App;

