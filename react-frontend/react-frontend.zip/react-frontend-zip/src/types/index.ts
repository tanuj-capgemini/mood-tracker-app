export type MoodType = 'Happy' | 'Neutral' | 'Stressed';

export interface MoodEntry {
  id: number;
  username: string;
  mood: MoodType;
  comment?: string;
  team?: Team | null;
  timestamp: string;
}

export interface Team {
  id: number;
  name: string;
  members: MoodEntry[];
}

