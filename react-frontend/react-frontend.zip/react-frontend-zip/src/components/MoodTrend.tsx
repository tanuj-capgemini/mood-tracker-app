import React from 'react';
import { MoodEntry } from '../types';
import { Line } from 'react-chartjs-2';
import { Chart as ChartJS, LineElement, PointElement, CategoryScale, LinearScale, Tooltip, Legend } from 'chart.js';

ChartJS.register(LineElement, PointElement, CategoryScale, LinearScale, Tooltip, Legend);

interface Props {
  entries: MoodEntry[];
}

const MoodTrend: React.FC<Props> = ({ entries }) => {
  const sortedEntries = [...entries].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

  const data = {
    labels: sortedEntries.map((entry) => new Date(entry.timestamp).toLocaleDateString()),
    datasets: [
      {
        label: 'Mood Trend',
        data: sortedEntries.map((entry) => {
          if (entry.mood === 'Happy') return 3;
          if (entry.mood === 'Neutral') return 2;
          return 1;
        }),
        fill: false,
        borderColor: '#2196f3',
        tension: 0.1,
      },
    ],
  };

  return (
    <div>
      {/* <h3>Mood Trend Over Time</h3> */}
      {data ? <Line data={data} /> : null}
    </div>
  );
};

export default MoodTrend;