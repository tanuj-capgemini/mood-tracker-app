import React, { useState } from 'react';
import {
    Grid,
    TextField,
    Button,
    MenuItem,
    Box,
    Typography,
    Paper,
} from '@mui/material';
import { MoodType, MoodEntry } from '../types';
import { createMoodEntry } from '../services/api';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';

const moods: MoodType[] = ['Happy', 'Neutral', 'Stressed'];

const MoodForm: React.FC<{ onSubmit?: () => void }> = ({ onSubmit }) => {
    const navigate = useNavigate();
    const [username, setUsername] = useState('');
    const [mood, setMood] = useState<MoodType>('Happy');
    const [comment, setComment] = useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        const newEntry: Partial<MoodEntry> = {
            username,
            mood,
            comment,
            timestamp: new Date().toISOString(),
        };
        try {
            console.log('entries...', newEntry);
            await createMoodEntry(newEntry);
            setUsername('');
            setMood('Happy');
            setComment('');
            if (onSubmit) onSubmit();
            toast.success('Mood submitted successfully!');
            setTimeout(()=>{
                navigate('/dashboard');
            },2500)
        } catch (error) {
            console.error('Error submitting mood:', error);
        }
    };

    return (
        <Paper elevation={3} sx={{ p: 4, maxWidth: 600, margin: 'auto', mt: 5 }}>
            <Typography variant="h5" gutterBottom>
                Submit Your Mood
            </Typography>
            <Box component="form" onSubmit={handleSubmit}>
                <Grid container spacing={2}>

                    <TextField
                        label="Username"
                        fullWidth
                        required
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                    />
                    <TextField
                        select
                        label="Mood"
                        fullWidth
                        value={mood}
                        onChange={(e) => setMood(e.target.value as MoodType)}
                    >
                        {moods.map((m) => (
                            <MenuItem key={m} value={m}>
                                {m}
                            </MenuItem>
                        ))}
                    </TextField>

                    <TextField
                        label="Comment"
                        fullWidth
                        multiline
                        rows={3}
                        value={comment}
                        onChange={(e) => setComment(e.target.value)}
                    />

                    <Button type="submit" variant="contained" fullWidth>
                        Submit
                    </Button>

                </Grid>
            </Box>
        </Paper>
    );
};

export default MoodForm;
