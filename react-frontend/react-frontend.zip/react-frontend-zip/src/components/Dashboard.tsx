import React, { useEffect, useState } from 'react';
import {
  Grid,
  Card,
  CardContent,
  Typography,
  Box,
  Container,
  Divider,
} from '@mui/material';
import { MoodEntry, Team } from '../types';
import { getMoodEntries, getTeams } from '../services/api';
import MoodChart from './MoodChart';
import MoodTrend from './MoodTrend';

const Dashboard: React.FC = () => {
  const [entries, setEntries] = useState<MoodEntry[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);

  useEffect(() => {
    const fetchEntries = async () => {
      try {
        const response = await getMoodEntries();
        setEntries(response.data.data.map((item: any) => ({
          id: item.id,
          mood: item.mood,
          username: item.username,
          comment: item.comment,
          timestamp: item.timestamp,
          ...item.attributes,
        })));

        // Teams list
        const teams_response = await getTeams();
        setTeams(teams_response.data.data.map((item: any) => ({
          id: item.id,
          name: item.name,
          ...item.attributes,
        })));
      } catch (error) {
        console.error('Error fetching mood entries:', error);
      }
    };
    fetchEntries();
  }, []);
  console.log(teams);

  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h4" gutterBottom>
        Team Mood Dashboard 
      </Typography>

      <Grid container spacing={14}>
        {/* Left: Mood Entries */}
          <Card elevation={3}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Latest Mood Entries
              </Typography>
              <Divider sx={{ mb: 2 }} />
              <Box sx={{ maxHeight: 400, overflowY: 'auto' }}>
                {entries.map((entry) => (
                  <Box key={entry.id} sx={{ mb: 2 }}>
                    <Typography variant="subtitle1" fontWeight="bold">
                      {entry.username}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Mood: {entry.mood} | {new Date(entry.timestamp).toLocaleString()}
                    </Typography>
                    {entry.comment && (
                      <Typography variant="body2" sx={{ mt: 0.5 }}>
                        {entry.comment}
                      </Typography>
                    )}
                    <Divider sx={{ mt: 1 }} />
                  </Box>
                ))}
              </Box>
            </CardContent>
          </Card>
    
      
          <Card elevation={3}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Mood Distribution
              </Typography>
              <Divider sx={{ mb: 2 }} />
              <MoodChart entries={entries} />
            </CardContent>
          </Card>
    
        {/* Bottom: Mood Trend */}
          <Card elevation={3}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Mood Trend Over Time
              </Typography>
              <Divider sx={{ mb: 2 }} />
              <MoodTrend entries={entries} />
            </CardContent>
          </Card>
        
      </Grid>
    </Container>
  );
};

export default Dashboard;