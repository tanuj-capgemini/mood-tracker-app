import React from 'react';
import { FormControl, InputLabel, Select, MenuItem } from '@mui/material';

interface Props {
  teams?: string[];
  selectedTeam: string;
  onSelectTeam: (team: string) => void;
}

const TeamFilter: React.FC<Props> = ({ teams = [], selectedTeam, onSelectTeam }) => {
  console.log('teams are inside team filter...', teams);
  return (
    <FormControl fullWidth sx={{ mb: 4 }}>
      <InputLabel>Filter by Team</InputLabel>
      <Select
        value={selectedTeam}
        label="Filter by Team"
        onChange={(e) => onSelectTeam(e.target.value)}
      >
        <MenuItem value="">All Teams</MenuItem>
        {teams.map((team) => (
          <MenuItem key={team} value={team}>{team}</MenuItem>
        ))}
      </Select>
    </FormControl>
  );
};

export default TeamFilter;
