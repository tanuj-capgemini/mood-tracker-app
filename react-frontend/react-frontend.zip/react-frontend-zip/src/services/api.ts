import axios from 'axios';

const BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:1337/api'

export const getMoodEntries = () => axios.get(`${BASE_URL}/mood-entries`);
export const getTeams = () => axios.get(`${BASE_URL}/teams`);
export const createMoodEntry = (data: any) => axios.post(`${BASE_URL}/mood-entries`, { data });