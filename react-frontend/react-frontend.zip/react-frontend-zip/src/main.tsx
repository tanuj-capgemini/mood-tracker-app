export default function main(){
    return <h2>This this main component</h2>
}