
# Mood Tracker – Strapi Backend Overlay (PostgreSQL)

This overlay contains **src** and **config** for a Strapi v4 app on **PostgreSQL**. All routes are open (no custom auth policies). For evaluation, enable the **Public** role permissions in Strapi Admin as described below.

## Prerequisites
- Node.js 18+ >= &  < 23 (Not Supported (e.g. v21, v23))
- PostgreSQL 13+

## Setup
1) Create a fresh Strapi app:
```bash
npx create-strapi@latest strapi-backend 
```
2) Install PostgreSQL driver:
```bash
cd strapi-backend
npm i pg
cd ..
```
3) Copy this overlay on top of your Strapi app root:
```bash
cp -r ./strapi-backend-src/* ./strapi-backend/
```
4) Create `./strapi-backend/.env` from the example below and adjust values, then start:
```bash
cd strapi-backend
npm run develop
```
5) Open **http://localhost:1337/admin** → create admin → set **Roles & Permissions**:
   - **Public**: enable
     - `team`: `find`, `findOne`
     - `mood-entry`: `find`, `findOne`, `create`
     - Also enable the custom route **`mood-entries` → `stats`** in the same section.

## .env example (strapi-backend/.env)
```
APP_KEYS=devKey1,devKey2,devKey3,devKey4
HOST=0.0.0.0
PORT=1337
NODE_ENV=development

# PostgreSQL
DATABASE_CLIENT=postgres
DATABASE_HOST=127.0.0.1
DATABASE_PORT=5432
DATABASE_NAME=mood_tracker_db
DATABASE_USERNAME=admin
DATABASE_PASSWORD=admin
DATABASE_SSL=false
```

## Custom Endpoint
- `GET /api/mood-entries/`.

## CORS
CORS is configured to allow CRA dev server `http://localhost:3000`. Edit `config/middlewares.js` if needed.