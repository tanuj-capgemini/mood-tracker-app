/**
 * mood-entry service
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreService('api::mood-entry.mood-entry');
